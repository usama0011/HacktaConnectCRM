// /config/mangoProxy.js
export const MANGO_PROXY_API_KEY =
  "mango_c32196c4a457fcb26b6c456160a520c1ad87b75450998498cd0eabb12fd642f8";
export const MANGO_PROXY_BASE_URL =
  "https://api.mangoproxy.com/v1/public-api/v1/statistics/account"; // Update if different
